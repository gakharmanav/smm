<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'fzresult_socailp');
define('DB_PASS', 'z56yruT=6W[5');
define('DB_NAME', 'fzresult_socailplugs');
define('TIMEZONE', 'Asia/Kolkata');
define('ENCRYPTION_KEY', '0d8e93aeac1e1e00b4d23e06c6697467');
